﻿namespace WpfAppMemory
{
    /// <summary>
    /// Уровень игры
    /// </summary>
    public enum Level
    {
        first=4,
		nextFirst = 6,
		second =8,
		nextSecond = 10,
		third =12
    }
}
