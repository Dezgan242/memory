﻿using System.Windows;

namespace WpfAppMemory
{
    /// <summary>
    /// WindowHelp
    /// </summary>
    public partial class WindowHelp : Window
    {
        public WindowHelp()
        {
            InitializeComponent();
        }

        private void Button_Click_Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
